"""
Notifpal SDK

This project is an interface for connecting to Notifpal service via python back-end projects.
"""

__version__ = "0.0.5"
__author__ = 'Pedram Dehghanpour'
__credits__ = 'Mahdaad Group'
