HOST = ""
PORT = 8080
KEY = ""
REGION = ""

buffer_channels = {}
